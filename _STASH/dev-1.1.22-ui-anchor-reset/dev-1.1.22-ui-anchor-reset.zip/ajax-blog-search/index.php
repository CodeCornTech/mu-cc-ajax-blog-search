<?php
/**
 * CodeCorn is golden .
 */
